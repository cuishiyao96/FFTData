Benchmark for the paper [FFT: Towards Harmlessness Evaluation and Analysis for LLMs
with Factuality, Fairness, Toxicity](https://arxiv.org/abs/2311.18580)

The Taxonomy:

![](https://raw.githubusercontent.com/cuishiyao96/FFT/main/Figures/Taxonomy.png)


If our paper is helpful for you, please cite it as:
```
citation
```